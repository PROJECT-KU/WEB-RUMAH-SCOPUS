<script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="00eb19ca-299f-49ff-ae28-4f8ed4915bcf";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>
<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
    </div> <strong>Copyright &copy; 2020 <a href="http://adminlte.io">Rumah Scopus</a>.</strong> All rights
    reserved.
</footer>

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->