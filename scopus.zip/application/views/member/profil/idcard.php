<body>
<style background-image:"theme/images/idcard.png"></style> 
    <img  src="<?= base_url('theme/images/idcard.png')?>" class="card-img" alt="...">
</body>